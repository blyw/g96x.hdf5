#include "Structs.h"


Structs::Structs()
{
}


Structs::~Structs()
{
}
